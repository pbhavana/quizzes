public class EmployeeNotFoundException extends Exception
{
//	private final ErrorCode code;
	
	public EmployeeNotFoundException(String flag)
	{
		super(flag);
	}
}


